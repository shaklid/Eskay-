<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/encryption.php';

require_admin();

$totalUsers = $pdo->query("SELECT COUNT(*) AS c FROM users WHERE role = 'user'")->fetch()['c'];
$totalTransactions = $pdo->query("SELECT COUNT(*) AS c FROM transactions")->fetch()['c'];
$flaggedCount = $pdo->query("SELECT COUNT(*) AS c FROM transactions WHERE is_flagged = 1")->fetch()['c'];

$flagged = $pdo->query(
    "SELECT t.*, u1.full_name AS sender_name, u2.full_name AS receiver_name, f.reason, f.risk_level, f.reviewed
     FROM transactions t
     JOIN users u1 ON t.sender_id = u1.user_id
     JOIN users u2 ON t.receiver_id = u2.user_id
     LEFT JOIN fraud_logs f ON f.transaction_id = t.transaction_id
     WHERE t.is_flagged = 1
     ORDER BY t.created_at DESC"
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Security Support System</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="top-nav">
        <div><strong>Admin Dashboard</strong></div>
        <a href="../logout.php">Logout</a>
    </div>

    <div class="container wide">
        <h2>Overview</h2>
        <p>
            Total Users: <strong><?= (int) $totalUsers ?></strong> &nbsp;|&nbsp;
            Total Transactions: <strong><?= (int) $totalTransactions ?></strong> &nbsp;|&nbsp;
            Flagged Transactions: <strong class="flag-high"><?= (int) $flaggedCount ?></strong>
        </p>

        <h2>Flagged Transactions</h2>
        <table>
            <tr>
                <th>Date</th>
                <th>From</th>
                <th>To</th>
                <th>Amount</th>
                <th>Reason</th>
                <th>Risk</th>
                <th>Reviewed</th>
            </tr>
            <?php foreach ($flagged as $txn): ?>
                <tr>
                    <td><?= clean($txn['created_at']) ?></td>
                    <td><?= clean($txn['sender_name']) ?></td>
                    <td><?= clean($txn['receiver_name']) ?></td>
                    <td>NGN <?= number_format((float) aes_decrypt($txn['amount_encrypted']), 2) ?></td>
                    <td><?= clean($txn['reason'] ?? '') ?></td>
                    <td class="flag-<?= $txn['risk_level'] === 'high' ? 'high' : 'low' ?>">
                        <?= clean(ucfirst($txn['risk_level'] ?? '')) ?>
                    </td>
                    <td><?= $txn['reviewed'] ? 'Yes' : 'No' ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($flagged)): ?>
                <tr><td colspan="7">No flagged transactions.</td></tr>
            <?php endif; ?>
        </table>
    </div>
</body>
</html>
