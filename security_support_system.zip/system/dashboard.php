<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/encryption.php';

require_login();

$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = :id");
$stmt->execute(['id' => $_SESSION['user_id']]);
$user = $stmt->fetch();

$stmt = $pdo->prepare(
    "SELECT t.*, u1.full_name AS sender_name, u2.full_name AS receiver_name
     FROM transactions t
     JOIN users u1 ON t.sender_id = u1.user_id
     JOIN users u2 ON t.receiver_id = u2.user_id
     WHERE t.sender_id = :uid OR t.receiver_id = :uid
     ORDER BY t.created_at DESC
     LIMIT 20"
);
$stmt->execute(['uid' => $user['user_id']]);
$transactions = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Security Support System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="top-nav">
        <div>Welcome, <?= clean($user['full_name']) ?></div>
        <div class="balance-badge">Balance: NGN <?= number_format($user['wallet_balance'], 2) ?></div>
        <a href="logout.php">Logout</a>
    </div>

    <div class="container wide">
        <h2>Transaction History</h2>
        <p><a href="transfer.php" class="btn" style="display:inline-block;width:auto;text-decoration:none;">+ New Transfer</a></p>

        <table>
            <tr>
                <th>Date</th>
                <th>From</th>
                <th>To</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Flag</th>
            </tr>
            <?php foreach ($transactions as $txn): ?>
                <tr>
                    <td><?= clean($txn['created_at']) ?></td>
                    <td><?= clean($txn['sender_name']) ?></td>
                    <td><?= clean($txn['receiver_name']) ?></td>
                    <td>NGN <?= number_format((float) aes_decrypt($txn['amount_encrypted']), 2) ?></td>
                    <td><?= clean(ucfirst($txn['status'])) ?></td>
                    <td>
                        <?php if ($txn['is_flagged']): ?>
                            <span class="flag-high">Flagged</span>
                        <?php else: ?>
                            &mdash;
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($transactions)): ?>
                <tr><td colspan="6">No transactions yet.</td></tr>
            <?php endif; ?>
        </table>
    </div>
</body>
</html>
