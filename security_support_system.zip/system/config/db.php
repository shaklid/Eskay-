<?php
/**
 * Database connection using PDO.
 * Update these credentials to match your local MySQL setup.
 */
$DB_HOST = 'localhost';
$DB_NAME = 'security_support_system';
$DB_USER = 'root';
$DB_PASS = '';

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [ PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION ]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
