<?php
/**
 * AES Encryption Key Configuration
 *
 * Security note: in a production system this key would be stored
 * OUTSIDE the web root (or in an environment variable / secrets
 * manager), separate from the database credentials, so that a
 * single leaked file cannot expose both the data and the key
 * needed to decrypt it. For this academic prototype, it is kept
 * in its own config file to demonstrate that separation.
 *
 * Generate your own random key by running once in a PHP shell:
 *   echo bin2hex(random_bytes(32));
 * and paste the 64-character result below.
 */
define('AES_SECRET_KEY', '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcd');
