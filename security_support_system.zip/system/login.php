<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/otp.php';

$errors = [];
$registered = isset($_GET['registered']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = clean($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        $errors[] = 'Invalid email or password.';
    } else {
        // First factor passed. Generate OTP for the second factor.
        $otp = generate_and_send_otp($pdo, (int) $user['user_id'], $user['email'], 'login');

        // Store a temporary, NOT-yet-fully-authenticated session
        $_SESSION['pending_user_id'] = $user['user_id'];
        $_SESSION['pending_role'] = $user['role'];
        $_SESSION['fully_authenticated'] = false;

        // Demo-only: show OTP on screen since no live mail server is configured.
        // Remove $_SESSION['demo_otp'] in a real deployment.
        $_SESSION['demo_otp'] = $otp;

        redirect('verify_otp.php?purpose=login');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Security Support System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Login</h2>

        <?php if ($registered): ?>
            <div class="alert alert-success">Registration successful. Please login.</div>
        <?php endif; ?>

        <?php foreach ($errors as $error): ?>
            <div class="alert alert-error"><?= clean($error) ?></div>
        <?php endforeach; ?>

        <form method="POST" action="login.php">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Login</button>
        </form>
        <p style="text-align:center; margin-top:16px;">
            Don't have an account? <a href="register.php">Register here</a>
        </p>
    </div>
</body>
</html>
