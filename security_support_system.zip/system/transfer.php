<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/encryption.php';
require_once __DIR__ . '/includes/otp.php';
require_once __DIR__ . '/includes/fraud.php';

require_login();

$errors = [];
$success = null;
$userId = (int) $_SESSION['user_id'];

// ------------------------------------------------------------------
// STEP 1: User submits the transfer form (receiver + amount)
// ------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['initiate_transfer'])) {
    $receiverEmail = clean($_POST['receiver_email'] ?? '');
    $amount = (float) ($_POST['amount'] ?? 0);

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->execute(['email' => $receiverEmail]);
    $receiver = $stmt->fetch();

    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = :id");
    $stmt->execute(['id' => $userId]);
    $sender = $stmt->fetch();

    if (!$receiver) {
        $errors[] = 'Recipient email not found.';
    } elseif ((int) $receiver['user_id'] === $userId) {
        $errors[] = 'You cannot transfer funds to yourself.';
    } elseif ($amount <= 0) {
        $errors[] = 'Enter a valid amount greater than zero.';
    } elseif ($amount > (float) $sender['wallet_balance']) {
        $errors[] = 'Insufficient wallet balance.';
    }

    if (empty($errors)) {
        // Save the pending transfer details in the session and require
        // OTP re-verification before the money actually moves.
        $_SESSION['pending_transfer'] = [
            'receiver_id' => $receiver['user_id'],
            'amount' => $amount,
        ];
        $_SESSION['pending_user_id'] = $userId; // reused by verify_otp.php
        $_SESSION['transaction_otp_verified'] = false;

        $otp = generate_and_send_otp($pdo, $userId, $sender['email'], 'transaction');
        $_SESSION['demo_otp'] = $otp;

        redirect('verify_otp.php?purpose=transaction');
    }
}

// ------------------------------------------------------------------
// STEP 2: User has returned from successful OTP verification -
// now actually process the transfer, running it through the
// fraud detection module and encrypting the stored amount.
// ------------------------------------------------------------------
if (isset($_GET['otp_verified']) && ($_SESSION['transaction_otp_verified'] ?? false) === true) {
    $pending = $_SESSION['pending_transfer'] ?? null;

    if ($pending) {
        $pdo->beginTransaction();
        try {
            $receiverId = (int) $pending['receiver_id'];
            $amount = (float) $pending['amount'];

            // Run fraud detection rules before finalising
            $fraudResult = evaluate_fraud_rules($pdo, $userId, $amount);

            $encryptedAmount = aes_encrypt((string) $amount);

            $stmt = $pdo->prepare(
                "INSERT INTO transactions (sender_id, receiver_id, amount_encrypted, status, is_flagged)
                 VALUES (:sender_id, :receiver_id, :amount_encrypted, 'completed', :is_flagged)"
            );
            $stmt->execute([
                'sender_id' => $userId,
                'receiver_id' => $receiverId,
                'amount_encrypted' => $encryptedAmount,
                'is_flagged' => $fraudResult['is_flagged'] ? 1 : 0,
            ]);
            $transactionId = $pdo->lastInsertId();

            if ($fraudResult['is_flagged']) {
                $logStmt = $pdo->prepare(
                    "INSERT INTO fraud_logs (transaction_id, reason, risk_level)
                     VALUES (:transaction_id, :reason, :risk_level)"
                );
                $logStmt->execute([
                    'transaction_id' => $transactionId,
                    'reason' => implode(' ', $fraudResult['reasons']),
                    'risk_level' => $fraudResult['risk_level'],
                ]);
            }

            // Move the funds (still completes even if flagged - monitoring, not blocking)
            $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance - :amount WHERE user_id = :id")
                ->execute(['amount' => $amount, 'id' => $userId]);
            $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + :amount WHERE user_id = :id")
                ->execute(['amount' => $amount, 'id' => $receiverId]);

            $pdo->commit();

            $success = $fraudResult['is_flagged']
                ? 'Transfer completed, but it was flagged for review due to unusual activity.'
                : 'Transfer completed successfully.';

            unset($_SESSION['pending_transfer'], $_SESSION['transaction_otp_verified'], $_SESSION['demo_otp']);
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = 'Transfer failed. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Transfer Funds - Security Support System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Transfer Funds</h2>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= clean($success) ?></div>
            <p><a href="dashboard.php">Back to Dashboard</a></p>
        <?php else: ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-error"><?= clean($error) ?></div>
            <?php endforeach; ?>

            <form method="POST" action="transfer.php">
                <input type="hidden" name="initiate_transfer" value="1">

                <label for="receiver_email">Recipient Email</label>
                <input type="email" id="receiver_email" name="receiver_email" required>

                <label for="amount">Amount (NGN)</label>
                <input type="number" id="amount" name="amount" min="1" step="0.01" required>

                <button type="submit">Continue</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
