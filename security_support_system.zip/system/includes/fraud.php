<?php
/**
 * Rule-based fraud detection.
 *
 * Evaluates a proposed transaction against a set of simple,
 * explainable rules. Returns an array describing whether the
 * transaction should be flagged, and why.
 *
 * Rules implemented:
 *  1. High-value transaction  - amount exceeds a fixed threshold
 *  2. Rapid repeated activity - more than N transactions by the
 *     same sender within the last SHORT_WINDOW_MINUTES
 */
const HIGH_VALUE_THRESHOLD = 200000.00;   // NGN 200,000
const RAPID_TXN_LIMIT = 3;                // max transactions allowed
const SHORT_WINDOW_MINUTES = 2;           // within this many minutes

function evaluate_fraud_rules(PDO $pdo, int $senderId, float $amount): array
{
    $reasons = [];
    $riskLevel = 'low';

    // Rule 1: high-value transaction
    if ($amount >= HIGH_VALUE_THRESHOLD) {
        $reasons[] = "Transaction amount (NGN " . number_format($amount, 2) . ") exceeds the high-value threshold.";
        $riskLevel = 'high';
    }

    // Rule 2: rapid repeated transactions
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) AS txn_count FROM transactions
         WHERE sender_id = :sender_id
           AND created_at >= (NOW() - INTERVAL :minutes MINUTE)"
    );
    $stmt->bindValue(':sender_id', $senderId, PDO::PARAM_INT);
    $stmt->bindValue(':minutes', SHORT_WINDOW_MINUTES, PDO::PARAM_INT);
    $stmt->execute();
    $count = (int) $stmt->fetch()['txn_count'];

    if ($count >= RAPID_TXN_LIMIT) {
        $reasons[] = "Sender has made $count transactions in the last " . SHORT_WINDOW_MINUTES . " minute(s), exceeding the allowed limit.";
        $riskLevel = 'high';
    }

    return [
        'is_flagged' => !empty($reasons),
        'reasons'    => $reasons,
        'risk_level' => $riskLevel,
    ];
}
