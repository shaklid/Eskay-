<?php
require_once __DIR__ . '/../config/key.php';

/**
 * Encrypts a plaintext value (e.g., a transaction amount) using
 * AES-256-CBC. A random initialisation vector (IV) is generated
 * for every call and prepended to the ciphertext so it can be
 * retrieved again for decryption. The result is base64-encoded
 * so it can be safely stored as TEXT in the database.
 */
function aes_encrypt(string $plaintext): string
{
    $key = hex2bin(AES_SECRET_KEY);
    $ivLength = openssl_cipher_iv_length('aes-256-cbc');
    $iv = openssl_random_pseudo_bytes($ivLength);

    $ciphertext = openssl_encrypt($plaintext, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);

    // Store IV + ciphertext together, base64-encoded for safe storage
    return base64_encode($iv . $ciphertext);
}

/**
 * Decrypts a value previously produced by aes_encrypt().
 */
function aes_decrypt(string $encoded): string|false
{
    $key = hex2bin(AES_SECRET_KEY);
    $data = base64_decode($encoded);

    $ivLength = openssl_cipher_iv_length('aes-256-cbc');
    $iv = substr($data, 0, $ivLength);
    $ciphertext = substr($data, $ivLength);

    return openssl_decrypt($ciphertext, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
}
