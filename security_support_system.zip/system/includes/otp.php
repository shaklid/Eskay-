<?php
require_once __DIR__ . '/../config/db.php';

/**
 * Generates a 6-digit OTP, stores it in the database with a
 * 5-minute expiry, and "sends" it to the user's email.
 *
 * NOTE: For demonstration purposes without a configured mail
 * server, the OTP is also returned so it can be displayed on
 * screen. In a real deployment, remove the on-screen display
 * and rely solely on the emailed/SMS code.
 */
function generate_and_send_otp(PDO $pdo, int $userId, string $email, string $purpose): string
{
    $otpCode = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $expiresAt = date('Y-m-d H:i:s', strtotime('+5 minutes'));

    $stmt = $pdo->prepare(
        "INSERT INTO otp_verifications (user_id, otp_code, purpose, expires_at)
         VALUES (:user_id, :otp_code, :purpose, :expires_at)"
    );
    $stmt->execute([
        'user_id'    => $userId,
        'otp_code'   => $otpCode,
        'purpose'    => $purpose,
        'expires_at' => $expiresAt,
    ]);

    send_otp_email($email, $otpCode, $purpose);

    return $otpCode;
}

/**
 * Sends the OTP via email using PHP's mail() function.
 * Requires a configured mail server (e.g., via php.ini's
 * sendmail_path, or a local SMTP relay) to actually deliver.
 */
function send_otp_email(string $email, string $otpCode, string $purpose): void
{
    $subject = "Your OTP Verification Code";
    $message = "Your one-time password (OTP) for $purpose is: $otpCode\n" .
               "This code will expire in 5 minutes. Do not share it with anyone.";
    $headers = "From: no-reply@ssscash.local";

    // @ suppresses warnings if no mail server is configured locally;
    // the OTP is still stored and can be verified via the on-screen fallback.
    @mail($email, $subject, $message, $headers);
}

/**
 * Verifies a submitted OTP code against the most recent,
 * unused, unexpired OTP issued to the user for the given purpose.
 */
function verify_otp(PDO $pdo, int $userId, string $submittedCode, string $purpose): bool
{
    $stmt = $pdo->prepare(
        "SELECT otp_id FROM otp_verifications
         WHERE user_id = :user_id
           AND purpose = :purpose
           AND otp_code = :otp_code
           AND is_used = 0
           AND expires_at >= NOW()
         ORDER BY otp_id DESC
         LIMIT 1"
    );
    $stmt->execute([
        'user_id' => $userId,
        'purpose' => $purpose,
        'otp_code' => $submittedCode,
    ]);
    $row = $stmt->fetch();

    if (!$row) {
        return false;
    }

    // Mark this OTP as used so it cannot be replayed
    $update = $pdo->prepare("UPDATE otp_verifications SET is_used = 1 WHERE otp_id = :id");
    $update->execute(['id' => $row['otp_id']]);

    return true;
}
