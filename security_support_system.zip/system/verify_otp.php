<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/otp.php';

// A pending login/transaction must exist before this page is useful
if (!isset($_SESSION['pending_user_id'])) {
    redirect('login.php');
}

$purpose = clean($_GET['purpose'] ?? 'login');
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submittedCode = clean($_POST['otp_code'] ?? '');
    $userId = (int) $_SESSION['pending_user_id'];

    if (verify_otp($pdo, $userId, $submittedCode, $purpose)) {
        if ($purpose === 'login') {
            // Promote the session to fully authenticated
            $_SESSION['user_id'] = $userId;
            $_SESSION['role'] = $_SESSION['pending_role'];
            $_SESSION['fully_authenticated'] = true;
            unset($_SESSION['pending_user_id'], $_SESSION['pending_role'], $_SESSION['demo_otp']);

            redirect($_SESSION['role'] === 'admin' ? 'admin/dashboard.php' : 'dashboard.php');
        } else {
            // Transaction OTP confirmed - flag session so transfer.php can proceed
            $_SESSION['transaction_otp_verified'] = true;
            redirect('transfer.php?otp_verified=1');
        }
    } else {
        $errors[] = 'Invalid or expired OTP code. Please try again.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verify OTP - Security Support System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Enter OTP</h2>
        <p>A 6-digit one-time password has been sent to your registered email. It expires in 5 minutes.</p>

        <?php if (isset($_SESSION['demo_otp'])): ?>
            <div class="alert alert-success">
                Demo mode (no live mail server configured): your OTP is
                <strong><?= clean($_SESSION['demo_otp']) ?></strong>
            </div>
        <?php endif; ?>

        <?php foreach ($errors as $error): ?>
            <div class="alert alert-error"><?= clean($error) ?></div>
        <?php endforeach; ?>

        <form method="POST" action="verify_otp.php?purpose=<?= clean($purpose) ?>">
            <label for="otp_code">OTP Code</label>
            <input type="text" id="otp_code" name="otp_code" maxlength="6" required autofocus>

            <button type="submit">Verify</button>
        </form>
    </div>
</body>
</html>
